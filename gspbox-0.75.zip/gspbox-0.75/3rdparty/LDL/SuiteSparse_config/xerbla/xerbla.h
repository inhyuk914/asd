void xerbla_ (char *srname, int *info) ;
void xerbla  (char *srname, int *info) ;
