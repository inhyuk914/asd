This is the CSCbox, a Matlab toolbox that implements the Compressive 
Spectral Clustering (CSC) algorithm as detailed in  

    N. Tremblay, G. Puy, R. Gribonval and P. Vandergheynst.
    Compressive Spectral Clustering.
    ArXiv e-prints:1602.02018 Feb. 2016.

The authors of this Toolbox are Nicolas Tremblay and Gilles Puy; 
and can both be joined at firstname.lastname AT inria DOT fr

This toolbox is probably not bug-free and this is its BETA-version. 
Please report any bug to help us improve it. 

This Toolbox is under the GNU Public License (see the attached 
document "LICENSE"). 

If you use this Toolbox, please kindly cite us! :-)
